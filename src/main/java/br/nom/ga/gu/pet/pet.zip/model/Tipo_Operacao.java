package br.nom.ga.gu.pet.model;

public enum Tipo_Operacao {
    ENTRADA,SAIDA;
}
