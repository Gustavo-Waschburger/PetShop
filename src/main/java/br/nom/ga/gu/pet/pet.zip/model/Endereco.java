package br.nom.ga.gu.pet.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Endereco {
    @Column(length = 150)
    private String logradouro;
    @Column(length = 10)
    private String numero;
    @Column(length = 50)
    private String bairro;
    @Column(length = 9)
    private String cep;
    @Id
    private Integer id;
    @ManyToOne
    @JoinColumn(name = "cliente_id", referencedColumnName = "id")
    private Cliente cliente;
}
